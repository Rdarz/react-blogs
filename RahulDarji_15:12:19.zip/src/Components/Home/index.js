import Home from './container'

export default Home
