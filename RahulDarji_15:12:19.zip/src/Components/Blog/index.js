import Blog from './container'

export default Blog
